
import ast
from app.opik_instrumentation import track

def _is_valid_python(func_src: str) -> bool:
    try:
        ast.parse(func_src)
        return True
    except Exception:
        return False

@track
def review(func_src: str) -> dict:
    ok = _is_valid_python(func_src)
    issues = []
    if not ok:
        issues.append("Generated code is not valid Python.")
    if "def " not in func_src:
        issues.append("No function definition found.")
    return {"valid": ok and not issues, "issues": issues}
