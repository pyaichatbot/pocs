
from app.opik_instrumentation import track

@track
def plan(task: str) -> list:
    steps = [
        "Understand the requirement and function signature.",
        "Sketch algorithm/logic in plain words.",
        "Write Python function with docstring and type hints.",
        "Return result and edge-case handling.",
        "Add simple test case inline as comment."
    ]
    return steps
