
from app.opik_instrumentation import track
from app.azure_client import get_model

model_call = get_model()

@track
def code(task: str, steps: list) -> str:
    prompt = f"""You are a helpful coding assistant.
Task: {task}
Steps: {steps}

Write a single Python function only. Keep it concise and correct. No extra prose.
"""
    messages = [
        {"role": "system", "content": "Return only the Python function, no backticks."},
        {"role": "user", "content": prompt}
    ]
    return model_call(messages)
