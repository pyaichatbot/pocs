
import argparse, textwrap
from app.agents.planner import plan
from app.agents.coder import code
from app.agents.reviewer import review

def run(task: str):
    print("\n[Planner] Task:", task)
    steps = plan(task)
    for i, s in enumerate(steps, 1):
        print(f"  {i}. {s}")

    print("\n[Coder] Generating code...")
    func_src = code(task, steps)
    print(textwrap.indent(func_src, prefix="    "))

    print("\n[Reviewer] Checking...")
    report = review(func_src)
    print("  Valid:", report["valid"])
    if report["issues"]:
        print("  Issues:")
        for it in report["issues"]:
            print("   -", it)
    return func_src, report

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--task", required=True, help="High-level task for the agent pipeline")
    args = ap.parse_args()
    run(args.task)
