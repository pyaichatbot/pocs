
# Multi‑Agent Workflow Demo with Opik (Planner → Coder → Reviewer)

This demo runs a tiny **agentic pipeline** locally and traces each step with **Opik**.
It uses **Azure OpenAI** if configured, else falls back to a local stub model.

## Pipeline
1. **Planner**: Breaks a user task into steps.
2. **Coder**: Generates a simple Python function (pure-text) for the task.
3. **Reviewer**: Checks the code with a basic validator and suggests fixes if needed.

## Quickstart
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

# Optional Azure OpenAI
export AZURE_OPENAI_KEY=...
export AZURE_OPENAI_ENDPOINT=https://<your-resource>.openai.azure.com/
export AZURE_OPENAI_API_VERSION=2024-02-15-preview
export AZURE_OPENAI_DEPLOYMENT=gpt-4o-mini

# Optional Opik
export USE_OPIK=1
export OPIK_USE_LOCAL=1

python main.py --task "Write a python function fizzbuzz(n) that returns a list from 1..n with Fizz/Buzz rules."
```
You'll see console output with each agent step and Opik will record traces if enabled.
