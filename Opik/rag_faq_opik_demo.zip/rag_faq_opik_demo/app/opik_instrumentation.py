
# Safe Opik setup: if opik is not installed, provide no-op decorators and classes.
import os
USE_OPIK = os.getenv("USE_OPIK", "0") == "1"

class _NoOp:
    def __call__(self, f):
        return f
    def __getattr__(self, name):
        return self
    def __call__(self, *a, **k):
        return None

track = lambda f: f  # default no-op
Guardrail = None
PII = None

client = None

if USE_OPIK:
    try:
        import opik
        from opik import track  # decorator
        try:
            from opik.guardrails import Guardrail, PII
        except Exception:
            Guardrail, PII = None, None
        client = opik
        if os.getenv("OPIK_USE_LOCAL") == "1":
            opik.configure(use_local=True)
        # If COMET_API_KEY is set, opik will use it for cloud
    except Exception as e:
        print(f"[opik] Warning: Opik not available or failed to init: {e}")
