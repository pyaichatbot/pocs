# Governance & Compliance

## Why It Matters
Regulated environment demands explainability, auditability, and data protection.

## SME Knowledge
- Access scopes, audit logs, explainability notes; DPIA for new use cases; model risk management.
- Separation of duties for approvals; RBAC for tool access.

## Mermaid – Governance Overlay
```mermaid
flowchart TD
  U[User Request] --> AIAI[Agentic Workflow]
  AIAI -->|Actions| SYS[Systems]
  AIAI -->|Events| LOG[Audit Logs]
  LOG --> GRC[GRC Review]
  GRC --> Pol[Policies/Controls]
```
## Audience Q&A
- **Q:** How do we stay safe?  
  **A:** HITL gates, MCP scopes, audit trails, and formal governance reviews.
