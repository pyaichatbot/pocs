# Model Context Protocol (MCP)

## What It Is
A standard to connect models/agents to enterprise tools and data **securely and consistently**.

## SME Knowledge
- Tool discovery, scoped invocation, auth tokens, streaming, observability.
- Benefits: portability, least-privilege access, auditability.

## Mermaid – Secure Tool Mediation
```mermaid
flowchart LR
  M[Model/Agent] -->|MCP| T[Tool Catalog]
  T -->|Scoped Call| S[Enterprise Systems]
  S --> L[Logs/Audit]
```
## Audience Q&A
- **Q:** Why MCP over ad hoc APIs?  
  **A:** It standardizes access, improves security/audit, and avoids one-offs.
