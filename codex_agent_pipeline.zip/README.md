Codex agent pipeline demo.
