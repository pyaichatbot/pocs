#!/bin/bash
echo fetch jira
