#!/bin/bash
echo create MR
