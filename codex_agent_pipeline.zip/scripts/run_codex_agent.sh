#!/bin/bash
echo run codex
