#!/bin/bash
echo apply push
